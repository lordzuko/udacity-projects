pip install -r floyd_requirements.txt
cp -r /code/* /output
cd /output
/run_jupyter.sh --no-browser --NotebookApp.base_url='/hqSi3fRgDj3VbSt3vaf8en' --NotebookApp.token='' --NotebookApp.allow_origin='*'